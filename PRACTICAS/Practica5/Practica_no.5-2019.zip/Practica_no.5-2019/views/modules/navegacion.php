<!-- NAV PARA HACER UN MENU DE NAVEGACION PARA LAS DIFERENTES VISTAS -->
<nav>
	<ul>
		<li><a href="index.php">Registro</a></li>
		<li><a href="index.php?action=ingresar">Ingreso</a></li>
		<li><a href="index.php?action=usuarios">Usuarios</a></li>
		<li><a href="index.php?action=salir">Salir</a></li>
		<li><a href="index.php?action=registroPro">Registrar Producto</a></li>
		<li><a href="index.php?action=productos">Productos</a></li>
		<li><a href="index.php?action=registroVen">Registrar Venta</a></li>
		<li><a href="index.php?action=ventas">Ventas</a></li>
	</ul>
</nav>